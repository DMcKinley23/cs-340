
from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the AAC animals collection."""

    def __init__(self, username="aacuser", password="GreenLantern"):
        # Configure the MongoDB connection.
        host = "localhost"
        port = 27017
        database_name = "aac"
        collection_name = "animals"

        self.client = MongoClient(
            f"mongodb://{username}:{password}@{host}:{port}/"
            "?authSource=admin",
            serverSelectionTimeoutMS=5000
        )

        self.database = self.client[database_name]
        self.collection = self.database[collection_name]

        # Verify that the server is reachable and authentication works.
        try:
            self.client.admin.command("ping")
        except PyMongoError:
            self.client.close()
            raise

    # CREATE
    def create(self, data):
        """Insert a document; return True on success, otherwise False."""
        if not isinstance(data, dict) or not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError:
            return False

    # READ
    def read(self, query):
        """Return matching documents as a list."""
        if not isinstance(query, dict):
            return []

        try:
            return list(self.collection.find(query))
        except PyMongoError:
            return []

    # UPDATE
    def update(self, query, new_data):
        """Update matching documents and return the number modified."""
        if (not isinstance(query, dict)
                or not isinstance(new_data, dict)
                or not query
                or not new_data):
            return 0

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_data}
            )
            return result.modified_count
        except PyMongoError:
            return 0

    # DELETE
    def delete(self, query):
        """Delete matching documents and return the number deleted."""
        if not isinstance(query, dict) or not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError:
            return 0
